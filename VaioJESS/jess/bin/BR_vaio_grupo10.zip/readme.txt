Instrucciones para la ejecuci�n de las consultas:

1. 	copiar el archivo "vaio.clp" que contiene las reglas de las consultas, 
	en el mismo directorio que el archivo jess.bat (generalmente en la carpeta /jess/bin).
2.	ejecutar jess.bat
3.	introducir en la consola de ejecuci�n el comando (batch vaio.clp)
4.	seguir las instrucciones que se muestran por pantalla